class Poker extends egret.DisplayObjectContainer {
    /**
     * 当前拎起的角
     */
    corner: string;
    /**
     * 当前移动方向
     */
    direction: string;
    origin: egret.Point;
    page_size: egret.Point;
    page_pos: egret.Point;

    handlerPage: egret.Sprite;
    staticPage: egret.Sprite;
    backPage: egret.Sprite;
    fontPage: egret.Sprite;

    animationContainer: egret.DisplayObjectContainer;

    shadow: egret.Bitmap;
    shadowLTR: egret.Bitmap;

    handlerPageMask: egret.Bitmap;
    staticMask: egret.Bitmap;

    tl: egret.Point;
    tr: egret.Point;
    bl: egret.Point;
    br: egret.Point;
    cornerSize: egret.Point;

    maskWidth: number;
    /**
     * 翻折中
     */
    folding: boolean = false;
    /**
     * 自动动画中
     */
    animating: boolean = false;

    private touchPoints: Object = { names: [] }; //{touchid:touch local,names:[ID1,ID2]};
    private touchCon: number = 0;
    tween: egret.Tween;

    /**
     * 翻牌阻尼的二次函数k，k越大翻的越容易
     */
    ratio: number = 15;
    /**
     * 动画速度
     */
    speed: number = 2;
    /**
     * 移动坐标记录 stage_pos
     */
    recoder: egret.Point;
    isSide: boolean = false;

    /**
     * 卡牌方向
     */
    ishorizontal: boolean = false;

    /**
     * debug
     */
    isDebug: boolean = false;
    public constructor() {
        super();
        this.setContainer()
        this.cornerSize = new egret.Point(100, 100)
    }
    /**
     * 设置热区，热区内触摸有效
     */
    setContainer() {
        egret.MainContext.instance.stage.addEventListener(egret.TouchEvent.TOUCH_MOVE, this.onMove, this);
        this.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onBegin, this);
        egret.MainContext.instance.stage.addEventListener(egret.TouchEvent.TOUCH_END, this.onEnd, this);
        egret.MainContext.instance.stage.addEventListener(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, this.onOutside, this);

    }
    /**
     * 纸牌的相对坐标，宽高，正面图，反面图，过程图,各类设置请在此之前设置好
     */
    setPoker(x, y, w, h, RES_font: string, RES_back: string, RES_font1: string) {
        this.removeChildren()
        this.page_size = new egret.Point(w, h);
        this.page_pos = new egret.Point(x, y);
        this.maskWidth = Math.ceil(Math.sqrt(this.page_size.x * this.page_size.x + this.page_size.y * this.page_size.y));
        this.init(RES_font, RES_back, RES_font1)
        this.initMask()
        this.hide();
        this.touchEnabled = true;

        if (this.isDebug) {
            this.initDebug();
        }
    }
    /**
     * 清理数据项
     */
    clearData() {
        this.folding = false;
        this.animating = false;
        this.origin = null;
        this.direction = null;
        this.corner = null;
        this.recoder = null;

        //clear pos;
        this.touchPoints = { names: [] };;
        this.touchCon = 0
    }
    /**
     * 按照参数翻转
     */
    flip(type: string) {
        this.clearData()

        this.staticPage.visible = false;
        this.handlerPage.visible = false;
        if (type === "font") {
            this.fontPage.visible = true;
            this.backPage.visible = false;
        } else if (type === "back") {
            this.touchEnabled = true;
            this.fontPage.visible = false;
            this.backPage.visible = true;
        }
        if (this.tween) {
            egret.Tween.removeTweens(this.tween);
        }
        this.initPos();
    }
    createPokerBitmap(res: string) {
        const sp = new egret.Sprite();
        const bm = this.createBitmapByName(res, sp);
        bm.width = this.page_size.x;
        bm.height = this.page_size.y;
        if (this.ishorizontal) {
            bm.width = this.page_size.y;
            bm.height = this.page_size.x;
            bm.y = this.page_size.y;
            bm.rotation = -90;
        }
        this.addChild(sp)
        return sp;
    }
    init(RES_font: string, RES_back: string, RES_font1: string) {
        const rootPos = this.page_pos
        this.tl = new egret.Point(rootPos.x, rootPos.y);
        this.tr = new egret.Point(rootPos.x + this.page_size.x, rootPos.y);
        this.bl = new egret.Point(rootPos.x, rootPos.y + this.page_size.y);
        this.br = new egret.Point(rootPos.x + this.page_size.x, rootPos.y + this.page_size.y);


        this.animationContainer = new egret.DisplayObjectContainer();
        this.addChild(this.animationContainer)


        this.fontPage = this.createPokerBitmap(RES_font);
        this.backPage = this.createPokerBitmap(RES_back);
        this.staticPage = this.createPokerBitmap(RES_back);

        this.handlerPage = new egret.Sprite()

        this.animationContainer.addChild(this.staticPage)
        this.animationContainer.addChild(this.handlerPage)


        const innermask = new egret.Sprite();
        innermask.graphics.beginFill(0x000000, 1);
        innermask.graphics.drawRect(0, 0, this.page_size.x, this.page_size.y);
        innermask.graphics.endFill();
        innermask.width = this.page_size.x;
        innermask.height = this.page_size.y;
        this.handlerPage.addChild(innermask);

        const innermaskLTR = new egret.Sprite();
        innermaskLTR.graphics.beginFill(0x000000, 1);
        innermaskLTR.graphics.drawRect(0, 0, this.page_size.x, this.page_size.y);
        innermaskLTR.graphics.endFill();
        innermaskLTR.width = this.page_size.x;
        innermaskLTR.height = this.page_size.y;
        this.handlerPage.addChild(innermaskLTR);

        const bit = this.createBitmapByName(RES_font1)
        bit.width = this.page_size.x;
        bit.height = this.page_size.y;
        if (this.ishorizontal) {
            bit.width = this.page_size.y;
            bit.height = this.page_size.x;
            bit.y = this.page_size.y;
            bit.rotation = -90;
        }
        this.handlerPage.addChild(bit);

        this.shadow = this.createBitmapByName("shadow_png")
        this.shadow.width = 150;
        this.shadow.height = 2 * this.maskWidth;
        this.shadow.mask = innermask;
        this.handlerPage.addChild(this.shadow)
        this.shadowLTR = this.createBitmapByName("shadowLTR_png")
        this.shadowLTR.width = 150;
        this.shadowLTR.height = 2 * this.maskWidth;
        this.shadowLTR.mask = innermaskLTR;
        this.handlerPage.addChild(this.shadowLTR)



        this.fontPage.width = this.page_size.x;
        this.fontPage.height = this.page_size.y;
        this.backPage.width = this.page_size.x;
        this.backPage.height = this.page_size.y;
        this.staticPage.width = this.page_size.x;
        this.staticPage.height = this.page_size.y;
        this.handlerPage.width = this.page_size.x;
        this.handlerPage.height = this.page_size.y;

        this.initPos();

    }
    initPos() {
        this.fontPage.x = this.tl.x;
        this.fontPage.y = this.tl.y;
        this.backPage.x = this.tl.x;
        this.backPage.y = this.tl.y;
        this.staticPage.x = this.tl.x;
        this.staticPage.y = this.tl.y;
        this.handlerPage.x = this.tl.x;
        this.handlerPage.y = this.tl.y;

        this.animationContainer.x = 0;
        this.animationContainer.y = 0;
    }
    debugMask: egret.Sprite
    debugPage: egret.Sprite;
    initDebug() {
        const innermask = new egret.Sprite();
        innermask.graphics.beginFill(0x000000, 0.3);
        innermask.graphics.drawRect(0, 0, this.maskWidth, this.maskWidth);
        innermask.graphics.endFill();
        innermask.width = this.maskWidth;
        innermask.height = this.maskWidth;
        this.addChild(innermask);
        this.debugMask = innermask;

        const innerpage = new egret.Sprite();
        innerpage.graphics.beginFill(0x000000, 0.3);
        innerpage.graphics.drawRect(0, 0, this.page_size.x, this.page_size.y);
        innerpage.graphics.endFill();
        innerpage.width = this.page_size.x;
        innerpage.height = this.page_size.y;
        this.addChild(innerpage);
        this.debugPage = innerpage;
    }
    initMask() {
        this.staticMask = this.buildMask("mask_png");
        this.handlerPageMask = this.buildMask("mask1_png");



        this.animationContainer.addChild(this.staticMask);
        this.animationContainer.addChild(this.handlerPageMask)

        this.handlerPage.mask = this.handlerPageMask;
        this.staticPage.mask = this.staticMask;
    }
    buildMask(file: string) {
        const mask = this.createBitmapByName(file)//new egret.Sprite();
        mask.width = this.maskWidth;
        mask.height = mask.width;
        // mask.graphics.beginFill(0x000000, 1);
        // mask.graphics.drawRect(0, 0, mask.height, mask.width);
        // mask.graphics.endFill();
        this.addChild(mask);
        return mask;
    }
    show() {
        this.staticPage.visible = true;
        this.handlerPage.visible = true;
        this.backPage.visible = false;
        this.fontPage.visible = false;
    }
    hide(isFlip: boolean = false) {
        if (this.isDebug) {
            //回调：结束
            console.log("回调：结束")
        }
        this.backPage.visible = true;
        this.fontPage.visible = false;

        this.staticPage.visible = false;
        this.handlerPage.visible = false;

        if (isFlip) {
            this.touchEnabled = false;
            this.backPage.visible = false;
            this.fontPage.visible = true;

        }

        this.clearData()

    }

    onOutside(evt) {
        this.onEnd(evt)
    }
    onEnd(evt: egret.TouchEvent) {
        let mp = this.handlerDoubleTouch(evt);
        this.touchCon = 0;
        delete this.touchPoints[evt.touchPointID];
        if (this.animating || !this.folding) { return }
        this._tween();
    }
    onMove(evt: egret.TouchEvent) {
        if (this.touchPoints[evt.touchPointID]) {
            this.touchPoints[evt.touchPointID].x = evt.stageX;
            this.touchPoints[evt.touchPointID].y = evt.stageY;
        } else { return }
        let mp = this.handlerDoubleTouch(evt);

        if (!this.origin || this.animating) { return; }
        const angle = Math.atan2(mp.x - this.origin.x, mp.y - this.origin.y) * 180 / Math.PI;
        if (!this.direction) {
            if ((angle > -180 && angle < -135) || (angle < 180 && angle > 135)) {
                this.direction = "up";
            } else if (angle > -45 && angle < 45) {
                this.direction = "down"
            } else if (angle > -135 && angle < -45) {
                this.direction = "left"
            } else if (angle < 135 && angle > 45) {
                this.direction = "right";
            }
            this.initPos();
        }
        if (this.origin && this.direction && this.corner && !this.animating) {
            //二次阻尼
            const posOffset = new egret.Point(mp.x - this.origin.x, mp.y - this.origin.y);
            const k = this.ratio;
            const mod = egret.Point.distance(mp, this.origin);
            const damped = Math.sqrt(mod) * k
            posOffset.x = 1 / mod * posOffset.x * damped
            posOffset.y = 1 / mod * posOffset.y * damped
            mp = this.origin.add(posOffset);
            if (!this.folding) {
                if (this.isDebug) {
                    //回调：开始翻
                    console.log("回调：开始翻")
                }

            }
            this._folding(mp, this.corner, this.direction);
        }
    }
    onBegin(evt: egret.TouchEvent) {
        if (this.animating || this.folding) { return }
        if (this.touchPoints[evt.touchPointID] == null) {
            this.touchPoints[evt.touchPointID] = new egret.Point(evt.stageX, evt.stageY);
            this.touchPoints["names"].push(evt.touchPointID);
            this.touchCon++;
        }



        let mp = this.handlerDoubleTouch(evt);
        this.corner = this.whichCorner(mp);
        if (this.corner) {
            this.origin = mp;

        }
    }
    whichCorner(stage_pos: egret.Point) {
        const tl = this.tl;
        const tr = this.tr;
        const bl = this.bl;
        const br = this.br;
        const l = this.globalToLocal(stage_pos.x, stage_pos.y);
        const x = l.x
        const y = l.y;
        const size = this.cornerSize
        let corner = null;
        this.isSide = false;
        //四角
        if (x > tl.x && x < (tl.x + size.x) && y > tl.y && y < (tl.y + size.y)) {
            corner = "tl";
        } else if (x > (tr.x - size.x) && x < tr.x && y > tr.y && y < (tr.y + size.y)) {
            corner = "tr";
        } else if (x > bl.x && x < (bl.x + size.x) && y > (bl.y - size.y) && y < bl.y) {
            corner = "bl";
        }
        else if (x > (br.x - size.x) && x < br.x && y > (br.y - size.y) && y < br.y) {
            corner = "br";
        }
        //四边
        else if (x > (tl.x + size.x) && x < (tr.x - size.x) && y > tl.y && y < (tl.y + size.y)) {
            //up
            this.isSide = true;
            corner = "tr";
        }
        else if (x > (bl.x + size.x) && x < (br.x - size.x) && y > (bl.y - size.y) && y < bl.y) {
            //DOWN
            this.isSide = true;

            corner = "bl";
        }
        else if (x > tl.x && x < (tl.x + size.x) && y > (tl.y + size.y) && y < (bl.y - size.y)) {
            //left
            this.isSide = true;

            corner = "tl";
        }
        else if (x > (tr.x - size.x) && x < tr.x && y > (tr.y + size.y) && y < (br.y - size.y)) {
            //right
            this.isSide = true;

            corner = "br";
        }
        else {
            corner = null;
        }
        return corner;
    }
    _cornerPos() {
        if (this.corner === "tl") {
            return this.tl;
        } else if (this.corner === "tr") {
            return this.tr;
        } else if (this.corner === "bl") {
            return this.bl;
        } else if (this.corner === "br") {
            return this.br;
        }
    }
    //约束到一个以翻折线为轴的两个圆的相交区域内
    _fixDragPos(drag_pos: egret.Point, direction: string, corner: string) {
        let pos = drag_pos;
        let center: egret.Point;
        let diagonal: egret.Point;
        let drag: egret.Point;
        const offset = 2;

        if (direction === "left") {

            if (corner === "tr") {
                pos.y = Math.max(this.tr.y + offset, pos.y)
                pos.x = Math.min(this.tr.x - offset, pos.x)
                if (this.isSide) {
                    pos.y = this.tr.y + offset;
                }
                if (this.isInTwoCircleCrossArea(pos, this.tl, this.page_size.x, this.bl, this.maskWidth)) {
                    if (pos.x === this.tl.x) {
                        pos.x -= offset
                    }
                    if (pos.y === this.tl.y) {
                        pos.y += offset
                    }
                    return pos;
                } else {
                    //内圆
                    if (pos.y > this.tr.y) {
                        const crosspoints = this.FindLineCircleIntersections(this.tl, this.page_size.x, this.tr, pos);
                        let validPos = this.find(crosspoints, (e) => e.y > this.tr.y);
                        if (validPos) {
                            validPos = egret.Point.interpolate(this.tl, validPos, offset / this.page_size.x);
                            return validPos
                        }
                    }
                    //外圆
                    else {
                        // const crosspoints = this.FindLineCircleIntersections(this.bl, this.maskWidth, new egret.Point(pos.x, this.tr.y), pos);
                        // let validPos = this.find(crosspoints, (e) => e.y < this.tr.y);
                        // if (validPos) {
                        //     validPos = egret.Point.interpolate(this.bl, validPos, 1 / this.maskWidth);
                        //     return validPos
                        // }
                    }
                }
                return this.tr.add(new egret.Point(-offset, offset))

            } else if (corner === "br") {
                pos.y = Math.min(pos.y, this.br.y)
                if (this.isSide) {
                    pos.y = this.br.y;
                }
                if (this.isInTwoCircleCrossArea(pos, this.bl, this.page_size.x, this.tl, this.maskWidth)) {
                    if (pos.x === this.bl.x) {
                        pos.x += offset
                    }
                    if (pos.y === this.bl.y) {
                        pos.y -= offset
                    }
                    return pos;
                } else {
                    //内圆
                    if (pos.y < this.br.y) {
                        const crosspoints = this.FindLineCircleIntersections(this.bl, this.page_size.x, this.br, pos);
                        let validPos = this.find(crosspoints, (e) => e.y < this.br.y);
                        if (validPos) {
                            validPos = egret.Point.interpolate(this.bl, validPos, offset / this.page_size.x);
                            return validPos;
                        }
                    }
                    //外圆
                    else {
                        const crosspoints = this.FindLineCircleIntersections(this.tl, this.maskWidth, new egret.Point(pos.x, this.br.y), pos);
                        // let validPos = this.find(crosspoints, (e) => e.y > this.br.y);
                        // if (validPos) {
                        //     validPos = egret.Point.interpolate(this.tl, validPos, 1 / this.maskWidth);
                        //     return validPos;
                        // }
                    }
                }
                return this.br.add(new egret.Point(-offset, -offset))
            }

        } else if (direction === "right") {
            if (corner === "tl") {
                pos.y = Math.max(pos.y, this.tl.y);
                if (this.isSide) {
                    pos.y = this.tl.y;
                }
                if (this.isInTwoCircleCrossArea(pos, this.tr, this.page_size.x, this.br, this.maskWidth)) {
                    if (pos.x === this.tr.x) {
                        pos.x -= offset
                    }
                    if (pos.y === this.tl.y) {
                        pos.y += offset
                    }
                    return pos;
                } else {
                    //内圆
                    if (pos.y > this.tl.y) {
                        const crosspoints = this.FindLineCircleIntersections(this.tr, this.page_size.x, this.tl, pos);
                        let validPos = this.find(crosspoints, (e) => e.y > this.tl.y);
                        if (validPos) {
                            validPos = egret.Point.interpolate(this.tr, validPos, offset / this.page_size.x);
                            return validPos;
                        }
                    }
                    //外圆
                    else {
                        const crosspoints = this.FindLineCircleIntersections(this.br, this.maskWidth, new egret.Point(pos.x, this.tl.y), pos);
                        // let validPos = this.find(crosspoints, (e) => e.y < this.tl.y);
                        // if (validPos) {
                        //     validPos = egret.Point.interpolate(this.br, validPos, 1 / this.maskWidth);
                        //     return validPos;
                        // }
                    }
                }
                return this.tl.add(new egret.Point(offset, offset));

            } else if (corner === "bl") {
                pos.y = Math.min(pos.y, this.bl.y);
                if (this.isSide) {
                    pos.y = this.bl.y;
                }
                if (this.isInTwoCircleCrossArea(pos, this.br, this.page_size.x, this.tr, this.maskWidth)) {
                    if (pos.x === this.tr.x) {
                        pos.x -= offset
                    }
                    if (pos.y === this.bl.y) {
                        pos.y -= offset
                    }
                    return pos;
                } else {
                    //内圆
                    if (pos.y < this.bl.y) {
                        const crosspoints = this.FindLineCircleIntersections(this.br, this.page_size.x, this.bl, pos);
                        let validPos = this.find(crosspoints, (e) => e.y < this.bl.y);
                        if (validPos) {
                            validPos = egret.Point.interpolate(this.br, validPos, offset / this.page_size.x);
                            return validPos;
                        }
                    }
                    //外圆
                    else {
                        // const crosspoints = this.FindLineCircleIntersections(this.tr, this.maskWidth, new egret.Point(pos.x, this.bl.y), pos);
                        // let validPos = this.find(crosspoints, (e) => e.y > this.bl.y);
                        // if (validPos) {
                        //     validPos = egret.Point.interpolate(this.tr, validPos, 1 / this.maskWidth);
                        //     return validPos;
                        // }
                    }
                }
                return this.bl.add(new egret.Point(offset, -offset))
            }

        } else if (direction === "up") {
            if (corner === "bl") {
                pos.x = Math.max(pos.x, this.bl.x);
                if (this.isSide) {
                    pos.x = this.bl.x;
                }

                if (this.isInTwoCircleCrossArea(pos, this.tl, this.page_size.y, this.tr, this.maskWidth)) {
                    if (pos.x === this.bl.x) {
                        pos.x += offset
                    }
                    if (pos.y === this.tl.y) {
                        pos.y += offset
                    }
                    return pos;
                } else {
                    //内圆
                    if (pos.x > this.bl.x) {
                        const crosspoints = this.FindLineCircleIntersections(this.tl, this.page_size.y, this.bl, pos);
                        let validPos = this.find(crosspoints, (e) => e.x > this.bl.x);
                        if (validPos) {
                            validPos = egret.Point.interpolate(this.tl, validPos, offset / this.page_size.y);
                            return validPos;
                        }
                    }
                    //外圆
                    else {
                        // const crosspoints = this.FindLineCircleIntersections(this.tr, this.maskWidth, new egret.Point(this.bl.x, pos.y), pos);
                        // let validPos = this.find(crosspoints, (e) => e.x < this.bl.x);
                        // if (validPos) {
                        //     validPos = egret.Point.interpolate(this.tr, validPos, 1 / this.maskWidth);
                        //     return validPos;
                        // }
                    }
                }
                return this.bl.add(new egret.Point(offset, -offset))
            } else if (corner === "br") {
                pos.x = Math.min(pos.x, this.br.x);
                if (this.isSide) {
                    pos.x = this.br.x;
                }
                if (this.isInTwoCircleCrossArea(pos, this.tr, this.page_size.y, this.tl, this.maskWidth)) {
                    if (pos.x === this.br.x) {
                        pos.x -= offset
                    }
                    if (pos.y === this.tr.y) {
                        pos.y += offset
                    }
                    return pos;
                } else {
                    //内圆
                    if (pos.x < this.tr.x) {
                        const crosspoints = this.FindLineCircleIntersections(this.tr, this.page_size.y, this.br, pos);
                        let validPos = this.find(crosspoints, (e) => e.x < this.br.x);
                        if (validPos) {
                            validPos = egret.Point.interpolate(this.br, validPos, offset / this.page_size.y);
                            return validPos;
                        }
                    }
                    //外圆
                    else {
                        // const crosspoints = this.FindLineCircleIntersections(this.tl, this.maskWidth, new egret.Point(this.br.x, pos.y), pos);
                        // let validPos = this.find(crosspoints, (e) => e.x > this.br.x);
                        // if (validPos) {
                        //     validPos = egret.Point.interpolate(this.tl, validPos, 1 / this.maskWidth);
                        //     return validPos;
                        // }
                    }
                }
                return this.br.add(new egret.Point(-offset, -offset))
            }
        }
        else if (direction === "down") {
            if (corner === "tl") {
                pos.x = Math.max(pos.x, this.tl.x);
                if (this.isSide) {
                    pos.x = this.tl.x;
                }
                if (this.isInTwoCircleCrossArea(pos, this.bl, this.page_size.y, this.br, this.maskWidth)) {
                    if (pos.x === this.tl.x) {
                        pos.x += offset
                    }
                    if (pos.y === this.bl.y) {
                        pos.y -= offset
                    }
                    return pos;
                } else {
                    //内圆
                    if (pos.x > this.tl.x) {
                        const crosspoints = this.FindLineCircleIntersections(this.bl, this.page_size.y, this.tl, pos);
                        let validPos = this.find(crosspoints, (e) => e.x > this.tl.x);
                        if (validPos) {
                            validPos = egret.Point.interpolate(this.bl, validPos, offset / this.page_size.y);
                            return validPos;
                        }
                    }
                    //外圆
                    else {
                        // const crosspoints = this.FindLineCircleIntersections(this.br, this.maskWidth, new egret.Point(this.tl.x, pos.y), pos);
                        // let validPos = this.find(crosspoints, (e) => e.x < this.tl.x);
                        // if (validPos) {
                        //     validPos = egret.Point.interpolate(this.br, validPos, 1 / this.maskWidth);
                        //     return validPos;
                        // }
                    }
                }
                return this.tl.add(new egret.Point(offset, offset))
            } else if (corner === "tr") {
                pos.x = Math.min(pos.x, this.tr.x);
                if (this.isSide) {
                    pos.x = this.tr.x;
                }
                if (this.isInTwoCircleCrossArea(pos, this.br, this.page_size.y, this.bl, this.maskWidth)) {
                    if (pos.x === this.tr.x) {
                        pos.x -= offset
                    }
                    if (pos.y === this.br.y) {
                        pos.y -= offset
                    }
                    return pos;
                } else {
                    //内圆
                    if (pos.x < this.tr.x) {
                        const crosspoints = this.FindLineCircleIntersections(this.br, this.page_size.y, this.tr, pos);
                        let validPos = this.find(crosspoints, (e) => e.x < this.tr.x);
                        if (validPos) {
                            validPos = egret.Point.interpolate(this.br, validPos, offset / this.page_size.y);
                            return validPos;
                        }
                    }
                    //外圆
                    else {
                        // const crosspoints = this.FindLineCircleIntersections(this.bl, this.maskWidth, new egret.Point(this.tr.x, pos.y), pos);
                        // let validPos = this.find(crosspoints, (e) => e.x > this.tr.x);
                        // if (validPos) {
                        //     validPos = egret.Point.interpolate(this.bl, validPos, 1 / this.maskWidth);
                        //     return validPos;
                        // }
                    }
                }
                return this.tr.add(new egret.Point(-offset, offset))
            }
        }
        return undefined;
    }
    //将触摸点转成牌角的拖拽点
    _transStage2Drag(stage_pos: egret.Point, corner: egret.Point) {
        const posOffset = new egret.Point(stage_pos.x - this.origin.x, stage_pos.y - this.origin.y);

        return corner.add(posOffset)
    }
    _folding(stage_pos: egret.Point, corner: string, direction: string) {
        this.folding = true;

        let drag: egret.Point;
        let center: egret.Point;
        let handlerAnchor: egret.Point;
        let maskAnchor: egret.Point;
        let maskPos: egret.Point;
        const shadowWidth = 150;
        let shadowBitmap: egret.Bitmap;
        let shadowBitMapAnchorOffset: egret.Point
        let shadowBitMapRotation: number;
        let angle: number;

        this.shadow.visible = false;
        this.shadowLTR.visible = false;
        //投影点
        let shadow: egret.Point;

        if (direction === "left") {
            if (corner === "tr") {
                handlerAnchor = new egret.Point(0, 0);
                const dragCorner = this.tr;
                const center = this.tl;
                const diagonal = this.bl;
                drag = this._transStage2Drag(stage_pos, dragCorner);
                drag = this._fixDragPos(drag, direction, corner);
                //处理后的drag为stage的移动向量加在拖拽点上在touchlayout中的内部坐标
                //翻页点和角点中点
                const m_o_mid = new egret.Point((dragCorner.x + drag.x) / 2, (dragCorner.y + drag.y) / 2);
                //中垂线斜率
                const k_mid = -1 / this.getSlope(dragCorner, drag);
                if (drag.y > this.tr.y) {
                    maskPos = center;
                    shadow = this.getProjectivePoint(m_o_mid, k_mid, maskPos);
                    const off = egret.Point.distance(maskPos, shadow);
                    maskAnchor = new egret.Point(this.maskWidth - off, 0)
                    angle = -this.angle(dragCorner, center, drag);
                } else {
                    maskPos = diagonal;
                    shadow = this.getProjectivePoint(m_o_mid, k_mid, maskPos);
                    const off = egret.Point.distance(maskPos, shadow);
                    maskAnchor = new egret.Point(this.maskWidth - off, this.maskWidth)
                    angle = this.angle(dragCorner, center, drag);
                }

                shadowBitmap = this.shadow;
                shadowBitMapAnchorOffset = new egret.Point(shadowBitmap.width, shadowBitmap.height / 2);
                shadowBitMapRotation = -angle;


            } else if (corner === "br") {
                handlerAnchor = new egret.Point(0, this.page_size.y);
                const dragCorner = this.br;
                const center = this.bl;
                const diagonal = this.tl;
                drag = this._transStage2Drag(stage_pos, dragCorner);
                drag = this._fixDragPos(drag, direction, corner);
                //翻页点和角点中点
                const m_o_mid = new egret.Point((dragCorner.x + drag.x) / 2, (dragCorner.y + drag.y) / 2);
                //中垂线斜率
                const k_mid = -1 / this.getSlope(dragCorner, drag);
                if (drag.y < this.br.y) {
                    maskPos = center;
                    shadow = this.getProjectivePoint(m_o_mid, k_mid, maskPos);
                    const off = egret.Point.distance(maskPos, shadow);
                    maskAnchor = new egret.Point(this.maskWidth - off, this.maskWidth)
                    angle = this.angle(dragCorner, center, drag);
                } else {
                    maskPos = diagonal;
                    shadow = this.getProjectivePoint(m_o_mid, k_mid, maskPos);
                    const off = egret.Point.distance(maskPos, shadow);
                    maskAnchor = new egret.Point(this.maskWidth - off, 0)
                    angle = -this.angle(dragCorner, center, drag) - 1;
                }
                shadowBitmap = this.shadow;
                shadowBitMapAnchorOffset = new egret.Point(shadowBitmap.width, shadowBitmap.height / 2);
                shadowBitMapRotation = -angle;
            } else {
                this.hide();
                return;
            }
        }
        else if (direction === "right") {
            if (corner === "tl") {
                handlerAnchor = new egret.Point(this.page_size.x, 0);
                const dragCorner = this.tl;
                const center = this.tr;
                const diagonal = this.br;
                drag = this._transStage2Drag(stage_pos, dragCorner);
                drag = this._fixDragPos(drag, direction, corner);
                //翻页点和角点中点
                const m_o_mid = new egret.Point((dragCorner.x + drag.x) / 2, (dragCorner.y + drag.y) / 2);
                //中垂线斜率
                const k_mid = -1 / this.getSlope(dragCorner, drag);
                if (drag.y > this.tl.y) {
                    maskPos = center;
                    shadow = this.getProjectivePoint(m_o_mid, k_mid, maskPos);
                    const off = egret.Point.distance(maskPos, shadow);
                    maskAnchor = new egret.Point(off, 0)
                    angle = this.angle(dragCorner, center, drag);
                } else {
                    maskPos = diagonal;
                    shadow = this.getProjectivePoint(m_o_mid, k_mid, maskPos);
                    const off = egret.Point.distance(maskPos, shadow);
                    maskAnchor = new egret.Point(off, this.maskWidth)
                    angle = -this.angle(dragCorner, center, drag);
                }
                shadowBitmap = this.shadowLTR;
                shadowBitMapAnchorOffset = new egret.Point(0, shadowBitmap.height / 2);
                shadowBitMapRotation = -angle;
            } else if (corner === "bl") {
                handlerAnchor = new egret.Point(this.page_size.x, this.page_size.y);
                const dragCorner = this.bl;
                const center = this.br;
                const diagonal = this.tr;
                drag = this._transStage2Drag(stage_pos, dragCorner);
                drag = this._fixDragPos(drag, direction, corner);
                //翻页点和角点中点
                const m_o_mid = new egret.Point((dragCorner.x + drag.x) / 2, (dragCorner.y + drag.y) / 2);
                //中垂线斜率
                const k_mid = -1 / this.getSlope(dragCorner, drag);
                if (drag.y < this.bl.y) {
                    maskPos = center;
                    shadow = this.getProjectivePoint(m_o_mid, k_mid, maskPos);
                    const off = egret.Point.distance(maskPos, shadow);
                    maskAnchor = new egret.Point(off, this.maskWidth)
                    angle = -this.angle(dragCorner, center, drag);
                } else {
                    maskPos = diagonal;
                    shadow = this.getProjectivePoint(m_o_mid, k_mid, maskPos);
                    const off = egret.Point.distance(maskPos, shadow);
                    maskAnchor = new egret.Point(off, 0)
                    angle = this.angle(dragCorner, center, drag);
                }
                shadowBitmap = this.shadowLTR;
                shadowBitMapAnchorOffset = new egret.Point(0, shadowBitmap.height / 2);
                shadowBitMapRotation = -angle;
            } else {
                this.hide();
                return;
            }
        } else if (direction === "up") {
            if (corner === "bl") {
                handlerAnchor = new egret.Point(0, 0);
                const dragCorner = this.bl;
                const center = this.tl;
                const diagonal = this.tr;
                drag = this._transStage2Drag(stage_pos, dragCorner);
                drag = this._fixDragPos(drag, direction, corner);
                //翻页点和角点中点
                const m_o_mid = new egret.Point((dragCorner.x + drag.x) / 2, (dragCorner.y + drag.y) / 2);
                //中垂线斜率
                const k_mid = -1 / this.getSlope(dragCorner, drag);
                if (drag.x > this.bl.x) {
                    maskPos = center;
                    shadow = this.getProjectivePoint(m_o_mid, k_mid, maskPos);
                    const off = egret.Point.distance(maskPos, shadow);
                    maskAnchor = new egret.Point(0, this.maskWidth - off)
                    angle = this.angle(dragCorner, center, drag);
                } else {
                    maskPos = diagonal;
                    shadow = this.getProjectivePoint(m_o_mid, k_mid, maskPos);
                    const off = egret.Point.distance(maskPos, shadow);
                    maskAnchor = new egret.Point(this.maskWidth, this.maskWidth - off)
                    angle = -this.angle(dragCorner, center, drag);
                }
                shadowBitmap = this.shadow;
                shadowBitMapAnchorOffset = new egret.Point(shadowBitmap.width, shadowBitmap.height / 2);
                shadowBitMapRotation = 90 - angle;
            } else if (corner === "br") {
                handlerAnchor = new egret.Point(this.page_size.x, 0);
                const dragCorner = this.br;
                const center = this.tr;
                const diagonal = this.tl;
                drag = this._transStage2Drag(stage_pos, dragCorner);
                drag = this._fixDragPos(drag, direction, corner);
                //翻页点和角点中点
                const m_o_mid = new egret.Point((dragCorner.x + drag.x) / 2, (dragCorner.y + drag.y) / 2);
                //中垂线斜率
                const k_mid = -1 / this.getSlope(dragCorner, drag);
                if (drag.x < this.br.x) {
                    maskPos = center;
                    shadow = this.getProjectivePoint(m_o_mid, k_mid, maskPos);
                    const off = egret.Point.distance(maskPos, shadow);
                    maskAnchor = new egret.Point(this.maskWidth, this.maskWidth - off)
                    angle = -this.angle(dragCorner, center, drag);
                } else {
                    maskPos = diagonal;
                    shadow = this.getProjectivePoint(m_o_mid, k_mid, maskPos);
                    const off = egret.Point.distance(maskPos, shadow);
                    maskAnchor = new egret.Point(0, this.maskWidth - off)
                    angle = this.angle(dragCorner, center, drag);
                }
                shadowBitmap = this.shadow;
                shadowBitMapAnchorOffset = new egret.Point(shadowBitmap.width, shadowBitmap.height / 2);
                shadowBitMapRotation = 90 - angle;
            } else {
                this.hide();

                return;
            }
        }
        else if (direction === "down") {
            if (corner === "tl") {
                handlerAnchor = new egret.Point(0, this.page_size.y);
                const dragCorner = this.tl;
                const center = this.bl;
                const diagonal = this.br;
                drag = this._transStage2Drag(stage_pos, dragCorner);
                drag = this._fixDragPos(drag, direction, corner);
                //翻页点和角点中点
                const m_o_mid = new egret.Point((dragCorner.x + drag.x) / 2, (dragCorner.y + drag.y) / 2);
                //中垂线斜率
                const k_mid = -1 / this.getSlope(dragCorner, drag);
                if (drag.x > this.tl.x) {
                    maskPos = center;
                    shadow = this.getProjectivePoint(m_o_mid, k_mid, maskPos);
                    const off = egret.Point.distance(maskPos, shadow);
                    maskAnchor = new egret.Point(0, off)
                    angle = -this.angle(dragCorner, center, drag);
                } else {
                    maskPos = diagonal;
                    shadow = this.getProjectivePoint(m_o_mid, k_mid, maskPos);
                    const off = egret.Point.distance(maskPos, shadow);
                    maskAnchor = new egret.Point(this.maskWidth, off)
                    angle = this.angle(dragCorner, center, drag);
                }
                shadowBitmap = this.shadowLTR;
                shadowBitMapAnchorOffset = new egret.Point(0, shadowBitmap.height / 2);
                shadowBitMapRotation = 90 - angle;
            } else if (corner === "tr") {
                handlerAnchor = new egret.Point(this.page_size.x, this.page_size.y);
                const dragCorner = this.tr;
                const center = this.br;
                const diagonal = this.bl;
                drag = this._transStage2Drag(stage_pos, dragCorner);
                drag = this._fixDragPos(drag, direction, corner);
                //翻页点和角点中点
                const m_o_mid = new egret.Point((dragCorner.x + drag.x) / 2, (dragCorner.y + drag.y) / 2);
                //中垂线斜率
                const k_mid = -1 / this.getSlope(dragCorner, drag);
                if (drag.x < this.tr.x) {
                    maskPos = center;
                    shadow = this.getProjectivePoint(m_o_mid, k_mid, maskPos);
                    const off = egret.Point.distance(maskPos, shadow);
                    maskAnchor = new egret.Point(this.maskWidth, off)
                    angle = this.angle(dragCorner, center, drag);
                } else {
                    maskPos = diagonal;
                    shadow = this.getProjectivePoint(m_o_mid, k_mid, maskPos);
                    const off = egret.Point.distance(maskPos, shadow);
                    maskAnchor = new egret.Point(0, off)
                    angle = -this.angle(dragCorner, center, drag);
                }
                shadowBitmap = this.shadowLTR;
                shadowBitMapAnchorOffset = new egret.Point(0, shadowBitmap.height / 2);
                shadowBitMapRotation = 90 - angle;
            } else {
                this.hide();

                return;
            }
        }
        else {
            this.hide();

            return;
        }

        shadowBitmap.visible = true;
        if (handlerAnchor.x == Number.NaN || handlerAnchor.y == Number.NaN || angle == Number.NaN || maskAnchor.x == Number.NaN || maskAnchor.y == Number.NaN) { return }

        if (Math.abs(Math.abs(angle) - 45) < 1) {
            return;
        }

        this.recoder = stage_pos;
        this.show();
        this.handlerPage.x = drag.x;
        this.handlerPage.y = drag.y;
        this.handlerPage.anchorOffsetX = handlerAnchor.x;
        this.handlerPage.anchorOffsetY = handlerAnchor.y;
        this.handlerPage.rotation = 2 * angle;

        this.handlerPageMask.x = maskPos.x;
        this.handlerPageMask.y = maskPos.y;
        this.handlerPageMask.anchorOffsetX = maskAnchor.x;
        this.handlerPageMask.anchorOffsetY = maskAnchor.y;
        this.handlerPageMask.rotation = angle;

        if (this.isDebug) {

            this.debugMask.x = maskPos.x;
            this.debugMask.y = maskPos.y;
            this.debugMask.anchorOffsetX = maskAnchor.x;
            this.debugMask.anchorOffsetY = maskAnchor.y;
            this.debugMask.rotation = angle;

            this.debugPage.x = drag.x;
            this.debugPage.y = drag.y;
            this.debugPage.anchorOffsetX = handlerAnchor.x;
            this.debugPage.anchorOffsetY = handlerAnchor.y;
            this.debugPage.rotation = 2 * angle;

            this.debug(drag)

        }

        this.staticMask.x = maskPos.x;
        this.staticMask.y = maskPos.y;
        this.staticMask.anchorOffsetX = maskAnchor.x;
        this.staticMask.anchorOffsetY = maskAnchor.y;
        this.staticMask.rotation = angle;


        const g = this.localToGlobal(shadow.x + this.animationContainer.x, shadow.y + this.animationContainer.y)
        const l = this.handlerPage.globalToLocal(g.x, g.y);
        shadowBitmap.x = l.x;
        shadowBitmap.y = l.y;
        shadowBitmap.anchorOffsetX = shadowBitMapAnchorOffset.x;
        shadowBitmap.anchorOffsetY = shadowBitMapAnchorOffset.y;
        shadowBitmap.rotation = shadowBitMapRotation

        if (!this.animating) {
            this._CheckToFont(direction);
        }

        // console.log("hv:" + this.handlerPage.visible)
        // console.log("hx:" + this.handlerPage.x + ";hy:" + this.handlerPage.y + ";hr:" + this.handlerPage.rotation)
        // console.log("hax:" + this.handlerPage.anchorOffsetX + ";hxy:" + this.handlerPage.anchorOffsetY)
        // console.log("mv:" + this.handlerPageMask.visible)
        // console.log("mx:" + this.handlerPageMask.x + ";my:" + this.handlerPageMask.y + ";mr:" + this.handlerPageMask.rotation)
        // console.log("max:" + this.handlerPageMask.anchorOffsetX + ";may:" + this.handlerPageMask.anchorOffsetY)


        if (this.isDebug) {
            //回调：翻中
            console.log("回调：翻中")
        }

    }
    dragPosInPokerArea(posDrag: egret.Point) {
        const g = this.localToGlobal(posDrag.x, posDrag.y);
        const l = this.backPage.globalToLocal(g.x, g.y);
        if (l.x > 0 && l.x < this.page_size.x && l.y > 0 && l.y < this.page_size.y) {
            return true;
        } else {
            return false;
        }
    }
    _CheckToFont(direction: string) {
        const g = this.handlerPage.localToGlobal(this.page_size.x / 2, this.page_size.y / 2);
        const g_rang_up = this.backPage.localToGlobal(0, 0).y;
        const g_rang_left = this.backPage.localToGlobal(0, 0).x;
        const g_rang_right = this.backPage.localToGlobal(this.page_size.x, this.page_size.y).x;
        const g_rang_down = this.backPage.localToGlobal(this.page_size.x, this.page_size.y).y;

        const g_back_center = this.backPage.localToGlobal(this.page_size.x / 2, this.page_size.y / 2);
        const inpoker = (g_center: egret.Point) => {
            return (g_center.x > g_rang_left && g_center.x < g_rang_right && g_center.y > g_rang_up && g_center.y < g_rang_down)
        }


        if (direction === "up") {
            const g2 = this.backPage.localToGlobal(this.page_size.x / 2, this.page_size.y);
            if (egret.Point.distance(g, g2) > (this.page_size.y / 2) && inpoker(g) && g.y < g_back_center.y) {
                this._tween(true);
                // this.flip("font");
            }
        } else if (direction === "down") {
            const g2 = this.backPage.localToGlobal(this.page_size.x / 2, 0);
            if (egret.Point.distance(g, g2) > (this.page_size.y / 2) && inpoker(g) && g.y > g_back_center.y) {
                this._tween(true);

                // this.flip("font");
            }
        } else if (direction === "left") {
            const g2 = this.backPage.localToGlobal(this.page_size.x, this.page_size.y / 2);
            if (egret.Point.distance(g, g2) > (this.page_size.x / 2) && inpoker(g) && g_back_center.x > g.x) {
                this._tween(true);

                // this.flip("font");
            }
        }
        else if (direction === "right") {
            const g2 = this.backPage.localToGlobal(0, this.page_size.y / 2);
            if (egret.Point.distance(g, g2) > (this.page_size.x / 2) && inpoker(g) && g_back_center.x < g.x) {
                this._tween(true);

                // this.flip("font");
            }
        }
    }
    _tweenTarget(currentPos: egret.Point) {
        let dragCorner: egret.Point;
        let cornerEnd: egret.Point;
        let direction = this.direction;
        let corner = this.corner;
        let target: egret.Point;
        if (direction === "up") {
            if (corner === "bl") {
                dragCorner = this.handlerPage.localToGlobal(0, 0)
                cornerEnd = this.backPage.localToGlobal(0, -this.page_size.y)
            } else if (corner === "br") {
                dragCorner = this.handlerPage.localToGlobal(this.page_size.x, 0)
                cornerEnd = this.backPage.localToGlobal(this.page_size.x, -this.page_size.y)
            }
        } else if (direction === "down") {
            if (corner === "tl") {
                dragCorner = this.handlerPage.localToGlobal(0, this.page_size.y)
                cornerEnd = this.backPage.localToGlobal(0, 2 * this.page_size.y)
            } else if (corner === "tr") {
                dragCorner = this.handlerPage.localToGlobal(this.page_size.x, this.page_size.y)
                cornerEnd = this.backPage.localToGlobal(this.page_size.x, 2 * this.page_size.y)
            }
        } else if (direction === "left") {
            if (corner === "tr") {
                dragCorner = this.handlerPage.localToGlobal(0, 0)
                cornerEnd = this.backPage.localToGlobal(-this.page_size.x, 0)
            } else if (corner === "br") {
                dragCorner = this.handlerPage.localToGlobal(0, this.page_size.y)
                cornerEnd = this.backPage.localToGlobal(-this.page_size.x, this.page_size.y)
            }
        } else if (direction === "right") {
            if (corner === "tl") {
                dragCorner = this.handlerPage.localToGlobal(this.page_size.x, 0)
                cornerEnd = this.backPage.localToGlobal(2 * this.page_size.x, 0)
            } else if (corner === "bl") {
                dragCorner = this.handlerPage.localToGlobal(this.page_size.x, this.page_size.y)
                cornerEnd = this.backPage.localToGlobal(2 * this.page_size.x, this.page_size.y)
            }
        }


        const offset = cornerEnd.subtract(dragCorner);
        target = currentPos.add(offset);
        return target;
    }
    _tween(isFlip: boolean = false) {
        this.animating = true;
        let _pos = { x: this.recoder.x, y: this.recoder.y, animX: 0, animY: 0 }
        const speed = this.speed;
        let target: egret.Point;
        let dragCorner: egret.Point;
        let to: Object;
        if (!this.recoder) { return }
        if (!isFlip) {
            target = this.origin;
            to = { x: target.x, y: target.y }

        } else {
            target = this._tweenTarget(this.recoder);
            target = this.stage.globalToLocal(target.x, target.y)
            const pos = new egret.Point(0, 0);
            if (this.direction === "up") {
                pos.y = this.page_size.y;
            } else if (this.direction === "down") {
                pos.y = -this.page_size.y
            } else if (this.direction === "left") {
                pos.x = this.page_size.x
            } else if (this.direction === "right") {
                pos.x = -this.page_size.x
            }
            to = { x: target.x, y: target.y, animX: pos.x, animY: pos.y }
        }

        const time = egret.Point.distance(this.recoder, target) / speed;
        if (this.tween) {
            egret.Tween.removeTweens(this.tween);
        }
        var tw = egret.Tween.get(_pos,
            {
                onChange: (e) => {
                    if (egret.Point.distance(new egret.Point(_pos.x, _pos.y), target) <= 2 && this.folding) {
                        if (isFlip) {
                            if (this.isDebug) {
                                //回调：翻正
                                console.log("回调：翻正")
                            }
                        } else {
                            if (this.isDebug) {
                                //回调：还原
                                console.log("回调：还原")
                            }

                        }

                        this.hide(isFlip)
                    } else if (this.animating) {
                        if (isFlip) {
                            this.animationContainer.x = _pos.animX;
                            this.animationContainer.y = _pos.animY;
                        }
                        this._folding(new egret.Point(_pos.x, _pos.y), this.corner, this.direction);
                    }
                },
                onChangeObj: _pos
            });
        tw.to(to, time)
            .call(() => {

            });
        this.tween = tw;
    }
    handlerDoubleTouch(evt: egret.TouchEvent) {

        let mp = new egret.Point(evt.stageX, evt.stageY);
        if (this.touchCon >= 2) {
            var names = this.touchPoints["names"];
            const t1 = this.touchPoints[names[names.length - 1]]
            const t2 = this.touchPoints[names[names.length - 2]]
            if (t1 && t2) {
                mp = new egret.Point((t1.x + t2.x) / 2, (t1.y + t2.y) / 2);
            }
        }
        return mp;
    }

    debug(mp: egret.Point) {

        const sprite = new egret.Sprite();
        sprite.graphics.beginFill(0xe8604e, 1);
        sprite.graphics.drawRect(0, 0, 1, 1);
        sprite.graphics.endFill();
        sprite.width = 1
        sprite.height = 1
        sprite.x = mp.x
        sprite.y = mp.y
        this.addChild(sprite)
    }
    find(array, func) {
        if (!array || !func) { return undefined }
        for (let i = 0; i < array.length; i++) {
            let e = array[i];
            if (func(e)) {
                return e
            }
        }
        return undefined;
    }
    private createBitmapByName(name: string, container: egret.DisplayObjectContainer = undefined): egret.Bitmap {
        let result = new egret.Bitmap();
        let texture: egret.Texture = RES.getRes(name);
        result.texture = texture;
        if (container) {
            container.addChild(result);

        } else {
            this.addChild(result);

        }
        return result;
    }

    public getSlope(point1: egret.Point, point2: egret.Point) {
        if (point1.x === point2.x) {
            throw "";
        }
        return (point2.y - point1.y) / (point2.x - point1.x);
    }
    public getProjectivePoint(pLine: egret.Point, k: number, pOut: egret.Point) {
        const point = new egret.Point();
        point.x = ((k * pLine.x + pOut.x / k + pOut.y - pLine.y) / (1 / k + k));
        point.y = (-1 / k * (point.x - pOut.x) + pOut.y);
        return point;
    }
    public angle(v0: egret.Point, v1: egret.Point, v2: egret.Point) {

        const va = new egret.Point(v1.x - v0.x, v1.y - v0.y)
        const vb = new egret.Point(v2.x - v0.x, v2.y - v0.y)

        const pvalue = va.x * vb.x + va.y * vb.y;
        const va_m = Math.sqrt(va.x * va.x + va.y * va.y);
        const vb_m = Math.sqrt(vb.x * vb.x + vb.y * vb.y);

        let cosV = pvalue / (va_m * vb_m);
        if (cosV < -1 && cosV > -2) {
            cosV = -1
        } else if (cosV > 1 && cosV < 2) {
            cosV = 1;
        }

        return Math.acos(cosV) * 180 / Math.PI
    }
    private isInTwoCircleCrossArea(point: egret.Point, c1: egret.Point, r1: number, c2: egret.Point, r2) {
        return egret.Point.distance(point, c1) < r1 && egret.Point.distance(point, c2) < r2;
    }


    // Find the points of intersection.
    private FindLineCircleIntersections(
        c: egret.Point, radius: number,
        point1: egret.Point, point2: egret.Point, ): Array<egret.Point> {
        let cx: number = c.x;
        let cy: number = c.y;
        let intersection1: egret.Point;
        let intersection2: egret.Point;
        let dx, dy, A, B, C, det, t;

        dx = point2.x - point1.x;
        dy = point2.y - point1.y;

        A = dx * dx + dy * dy;
        B = 2 * (dx * (point1.x - cx) + dy * (point1.y - cy));
        C = (point1.x - cx) * (point1.x - cx) +
            (point1.y - cy) * (point1.y - cy) -
            radius * radius;

        det = B * B - 4 * A * C;
        if ((A <= 0.0000001) || (det < 0)) {
            // No real solutions.
            intersection1 = new egret.Point(Number.NaN, Number.NaN);
            intersection2 = new egret.Point(Number.NaN, Number.NaN);
            return null;
        }
        else if (det == 0) {
            // One solution.
            t = -B / (2 * A);
            intersection1 =
                new egret.Point(point1.x + t * dx, point1.y + t * dy);
            intersection2 = new egret.Point(Number.NaN, Number.NaN);
            return [intersection1];
        }
        else {
            // Two solutions.
            t = ((-B + Math.sqrt(det)) / (2 * A));
            intersection1 =
                new egret.Point(point1.x + t * dx, point1.y + t * dy);
            t = ((-B - Math.sqrt(det)) / (2 * A));
            intersection2 =
                new egret.Point(point1.x + t * dx, point1.y + t * dy);
            return [intersection1, intersection2];
        }
    }

    buildShadowFilter(angle: number) {
        var distance: number = 100;           /// 阴影的偏移距离，以像素为单位
        var angle: number = angle;              /// 阴影的角度，0 到 360 度
        var color: number = 0x000000;        /// 阴影的颜色，不包含透明度
        var alpha: number = 0.7;             /// 光晕的颜色透明度，是对 color 参数的透明度设定
        var blurX: number = 26;              /// 水平模糊量。有效值为 0 到 255.0（浮点）
        var blurY: number = 0;              /// 垂直模糊量。有效值为 0 到 255.0（浮点）
        var strength: number = 0.65;                /// 压印的强度，值越大，压印的颜色越深，而且阴影与背景之间的对比度也越强。有效值为 0 到 255。暂未实现
        var quality: number = egret.BitmapFilterQuality.LOW;              /// 应用滤镜的次数，暂无实现
        var inner: boolean = true;            /// 指定发光是否为内侧发光
        var knockout: boolean = false;            /// 指定对象是否具有挖空效果
        var dropShadowFilter: egret.DropShadowFilter = new egret.DropShadowFilter(distance, angle, color, alpha, blurX, blurY,
            strength, quality, inner, knockout);
        return dropShadowFilter;
    }

}
