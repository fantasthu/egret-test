class Book extends egret.DisplayObjectContainer {

    corner: string;

    page: number = 0;
    page_size: egret.Point;


    leftPage: egret.Sprite;
    rightPage: egret.Sprite;
    handlerPage: egret.Sprite;
    staticPage: egret.Sprite;
    leftTemplePage: egret.Sprite;
    rightTemplePage: egret.Sprite;

    handlerPageMask: egret.Sprite;
    staticMask: egret.Sprite;

    tc: egret.Point;
    bc: egret.Point;

    maskWidth: number;

    folding: boolean = false;
    animating: boolean = false;

    book: egret.Sprite;


    public constructor() {
        super();
        this.init()
        this.setPage(0)
        this.initMask();
        this.hideAnim();

    }


    init() {
        this.page_size = new egret.Point(300, 500);
        const rootPos = new egret.Point(20, 200);
        this.tc = new egret.Point(rootPos.x + this.page_size.x, rootPos.y);
        this.bc = new egret.Point(rootPos.x + this.page_size.x, this.tc.y + this.page_size.y);

        this.width = 2000;
        this.height = 2000;

        this.book = new egret.Sprite();
        const book = this.book;
        book.graphics.beginFill(0xffffff, 0.1);
        book.graphics.drawRect(0, 0, this.width, this.height);
        book.graphics.endFill();
        book.width = this.width;
        book.height = this.height;
        this.addEventListener(egret.TouchEvent.TOUCH_MOVE, this.onMove, this);
        this.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onBegin, this);
        this.addEventListener(egret.TouchEvent.TOUCH_END, this.onEnd, this);
        book.touchEnabled = true;
        this.addChild(book);

        this.leftPage = this.buildPage(0xfffbe5);
        this.rightPage = this.buildPage(0xfffbe5);

        this.leftPage.filters = [this.buildShadowFilter(180)]
        this.rightPage.filters = [this.buildShadowFilter(0)]

        this.leftTemplePage = this.buildPage(0xfffbe5);
        this.rightTemplePage = this.buildPage(0xfffbe5);

        this.staticPage = this.buildPage(0xfffbe5);
        this.handlerPage = this.buildPage(0xfffbe5);


        this.leftPage.x = this.tc.x - this.page_size.x;
        this.leftPage.y = this.tc.y;
        this.rightPage.x = this.tc.x;
        this.rightPage.y = this.tc.y;

        this.leftTemplePage.x = this.leftPage.x;
        this.leftTemplePage.y = this.leftPage.y;
        this.rightTemplePage.x = this.rightPage.x;
        this.rightTemplePage.y = this.rightPage.y;

        this.handlerPage.x = this.tc.x;
        this.handlerPage.y = this.tc.y;
        this.staticPage.x = this.tc.x;
        this.staticPage.y = this.tc.y;
    }
    initMask() {
        this.staticMask = this.buildMask();
        this.handlerPageMask = this.buildMask();

        this.handlerPage.mask = this.handlerPageMask;
        this.staticPage.mask = this.staticMask;
    }
    hideAnim() {
        this.handlerPage.visible = false;
        this.staticPage.visible = false;
        this.leftTemplePage.visible = false;
        this.rightTemplePage.visible = false;
    }
    buildShadowFilter(angle:number) {
        var distance: number = 6;           /// 阴影的偏移距离，以像素为单位
        var angle: number = angle;              /// 阴影的角度，0 到 360 度
        var color: number = 0x000000;        /// 阴影的颜色，不包含透明度
        var alpha: number = 0.7;             /// 光晕的颜色透明度，是对 color 参数的透明度设定
        var blurX: number = 26;              /// 水平模糊量。有效值为 0 到 255.0（浮点）
        var blurY: number = 0;              /// 垂直模糊量。有效值为 0 到 255.0（浮点）
        var strength: number = 0.65;                /// 压印的强度，值越大，压印的颜色越深，而且阴影与背景之间的对比度也越强。有效值为 0 到 255。暂未实现
        var quality: number = egret.BitmapFilterQuality.LOW;              /// 应用滤镜的次数，暂无实现
        var inner: boolean = true;            /// 指定发光是否为内侧发光
        var knockout: boolean = false;            /// 指定对象是否具有挖空效果
        var dropShadowFilter: egret.DropShadowFilter = new egret.DropShadowFilter(distance, angle, color, alpha, blurX, blurY,
            strength, quality, inner, knockout);
        return dropShadowFilter;
    }
    showAnim() {
        console.log("show")
        this.handlerPage.visible = true;
        this.staticPage.visible = true;

        

        if (this.corner === "tl" || this.corner === "bl") {
            this.staticPage.filters = [this.buildShadowFilter(180)]
            this.staticPage.x = this.leftPage.x;
            this.staticPage.y = this.leftPage.y;
            (this.staticPage.getChildAt(0) as egret.TextField).text = (this.page * 2 - 1).toString() + "page";
            (this.handlerPage.getChildAt(0) as egret.TextField).text = (this.page * 2 - 2).toString() + "page";

            if (this.page > 1) {
                this.leftTemplePage.visible = true;
                (this.leftTemplePage.getChildAt(0) as egret.TextField).text = ((this.page - 1) * 2 - 1).toString() + "page";
            } else if (this.page === 1) {
                this.leftPage.visible = false;
            }
        } else {
            this.staticPage.filters = [this.buildShadowFilter(0)]
            this.staticPage.x = this.rightPage.x;
            this.staticPage.y = this.rightPage.y;
            (this.staticPage.getChildAt(0) as egret.TextField).text = (this.page * 2).toString() + "page";
            (this.handlerPage.getChildAt(0) as egret.TextField).text = (this.page * 2 + 1).toString() + "page";

            this.rightTemplePage.visible = true;
            (this.rightTemplePage.getChildAt(0) as egret.TextField).text = ((this.page + 1) * 2).toString() + "page";
        }

    }
    buildMask() {
        const mask = new egret.Sprite();
        mask.width = Math.ceil(Math.sqrt(this.page_size.x * this.page_size.x + this.page_size.y * this.page_size.y));
        mask.height = mask.width;
        this.maskWidth = mask.width;
        mask.graphics.beginFill(0xffffff, 1);
        mask.graphics.drawRect(0, 0, mask.height, mask.width);
        mask.graphics.endFill();
        this.addChild(mask);
        return mask;
    }
    setPage(page: number) {
        console.log("hide")
        this.folding = false;
        this.corner = null;
        this.handlerPage.visible = false;
        this.staticPage.visible = false;
        this.leftTemplePage.visible = false;
        this.rightTemplePage.visible = false;
        if (page < 0) { return; }
        this.page = page;
        this.leftPage.visible = true;
        this.rightPage.visible = true;
        if (page === 0) {
            this.leftPage.visible = false;
        }
        (this.leftPage.getChildAt(0) as egret.TextField).text = (page * 2 - 1).toString() + "page";
        (this.rightPage.getChildAt(0) as egret.TextField).text = (page * 2).toString() + "page";
    }
    buildPage(color: number) {
        const sprite = new egret.Sprite();
        sprite.graphics.beginFill(color, 1);
        sprite.graphics.drawRect(0, 0, this.page_size.x, this.page_size.y);
        sprite.graphics.endFill();
        sprite.width = this.page_size.x;
        sprite.height = this.page_size.y;

        let colorLabel = new egret.TextField();
        colorLabel.textColor = 0xf0f1a;
        colorLabel.width = this.page_size.x
        colorLabel.textAlign = "center";
        colorLabel.text = "page";
        colorLabel.size = 24;
        colorLabel.x = 0;
        colorLabel.y = 250;
        sprite.addChild(colorLabel);

        this.addChild(sprite)
        return sprite;

    }
    tween(pos: egret.Point) {
        if (this.animating) { return }
        this.animating = true;
        let _pos = { x: pos.x, y: pos.y }
        const speed = 1;
        let target: egret.Point = new egret.Point();
        let pageDirection: number = 0;
        if (_pos.x < this.tc.x) {
            if (this.corner === "tl") {
                target = new egret.Point(this.tc.x - this.page_size.x, this.tc.y);

            } else if (this.corner === "bl") {
                target = new egret.Point(this.bc.x - this.page_size.x, this.bc.y);

            } else if (this.corner === "tr") {
                target = new egret.Point(this.tc.x - this.page_size.x, this.tc.y);
                pageDirection = 1

            } else if (this.corner === "br") {
                target = new egret.Point(this.bc.x - this.page_size.x, this.bc.y);
                pageDirection = 1

            }
        } else {
            if (this.corner === "tl") {
                target = new egret.Point(this.tc.x + this.page_size.x, this.tc.y);
                pageDirection = -1

            } else if (this.corner === "bl") {
                target = new egret.Point(this.bc.x + this.page_size.x, this.bc.y);
                pageDirection = -1

            } else if (this.corner === "tr") {
                target = new egret.Point(this.tc.x + this.page_size.x, this.tc.y);

            } else if (this.corner === "br") {
                target = new egret.Point(this.bc.x + this.page_size.x, this.bc.y);
            }
        }
        const time = egret.Point.distance(pos, target) / speed
        var tw = egret.Tween.get(_pos,
            {
                onChange: (e) => {
                    this.fold(new egret.Point(_pos.x, _pos.y));
                },
                onChangeObj: _pos
            });
        tw.to({ x: target.x, y: target.y }, time)
            .call(() => {

            });
        setTimeout(() => {
            this.setPage(this.page + pageDirection)
            this.animating = false;

        }, time + 30);

    }


    private onEnd(evt: egret.TouchEvent) {
        console.log("end")
        this.tween(this.filterLocalPos(new egret.Point(evt.localX, evt.localY)));
    }
    private onMove(evt: egret.TouchEvent) {
        if (this.animating) { return }
        this.fold(new egret.Point(evt.localX, evt.localY))
    }
    filterLocalPos(pos: egret.Point) {
        let mp = new egret.Point(pos.x, pos.y);
        const tc = this.tc;
        const bc = this.bc;
        if (this.corner === "tl" || this.corner === "tr") {
            if (egret.Point.distance(mp, tc) > this.page_size.x && mp.y > tc.y) {
                mp = new egret.Point((mp.x - tc.x) / egret.Point.distance(mp, tc) * this.page_size.x + tc.x, (mp.y - tc.y) / egret.Point.distance(mp, tc) * this.page_size.x + tc.y);
            } else if (egret.Point.distance(mp, bc) > this.maskWidth) {
                mp = new egret.Point((mp.x - bc.x) / egret.Point.distance(mp, bc) * this.maskWidth + bc.x, (mp.y - bc.y) / egret.Point.distance(mp, bc) * this.maskWidth + bc.y);
            }
        } else {
            if (egret.Point.distance(mp, bc) > this.page_size.x && mp.y < bc.y) {
                mp = new egret.Point((mp.x - bc.x) / egret.Point.distance(mp, bc) * this.page_size.x + bc.x, (mp.y - bc.y) / egret.Point.distance(mp, bc) * this.page_size.x + bc.y);
            } else if (egret.Point.distance(mp, tc) > this.maskWidth) {
                mp = new egret.Point((mp.x - tc.x) / egret.Point.distance(mp, tc) * this.maskWidth + tc.x, (mp.y - tc.y) / egret.Point.distance(mp, tc) * this.maskWidth + tc.y);
            }
        }

        return mp;
    }
    fold(pos: egret.Point) {
        if (this.corner) {
            if (!this.folding) {
                this.showAnim();
                this.folding = true;
            }
            const x = pos.x;
            const y = pos.y;
            const tc = this.tc;
            const bc = this.bc;
            //处理翻页点
            let mp = this.filterLocalPos(pos);
            // const sprite = new egret.Sprite();
            // sprite.graphics.beginFill(0xe8604e, 1);
            // sprite.graphics.drawRect(0, 0, 1, 1);
            // sprite.graphics.endFill();
            // sprite.width = 1
            // sprite.height = 1
            // sprite.x = mp.x
            // sprite.y = mp.y
            // this.addChild(sprite)


            //mask 的中心坐标
            let anchorPoint: egret.Point;
            //mask 锚点偏移
            let anchorOffset: egret.Point;

            //起手区角点
            let ori: egret.Point;
            //mask锚点在中垂线上的投影，即mask角点
            let shadow_p: egret.Point;

            let center: egret.Point;
            //旋转角度
            let angle: number

            if (this.corner === "tr") {
                ori = new egret.Point(this.tc.x + this.page_size.x, this.tc.y);
                //翻页点和角点中点
                const m_o_mid = new egret.Point((mp.x + ori.x) / 2, (mp.y + ori.y) / 2);
                //中垂线斜率
                const k_mid = -1 / this.getSlope(mp, ori);

                if (mp.y > tc.y) {
                    anchorPoint = this.tc
                    shadow_p = this.getProjectivePoint(m_o_mid, k_mid, anchorPoint);
                    const p_s_distance = egret.Point.distance(anchorPoint, shadow_p);
                    angle = -this.angle(ori, mp, tc);
                    anchorOffset = new egret.Point(this.maskWidth - p_s_distance, 0)

                } else {
                    anchorPoint = this.bc
                    shadow_p = this.getProjectivePoint(m_o_mid, k_mid, anchorPoint);
                    const p_s_distance = egret.Point.distance(anchorPoint, shadow_p);
                    angle = this.angle(ori, mp, tc);
                    anchorOffset = new egret.Point(this.maskWidth - p_s_distance, this.maskWidth)

                }
            } else if (this.corner === "tl") {
                ori = new egret.Point(this.tc.x - this.page_size.x, this.tc.y);
                //翻页点和角点中点
                const m_o_mid = new egret.Point((mp.x + ori.x) / 2, (mp.y + ori.y) / 2);
                //中垂线斜率
                const k_mid = -1 / this.getSlope(mp, ori);

                if (mp.y > tc.y) {
                    anchorPoint = this.tc
                    shadow_p = this.getProjectivePoint(m_o_mid, k_mid, anchorPoint);
                    const p_s_distance = egret.Point.distance(anchorPoint, shadow_p);
                    angle = this.angle(ori, mp, tc);
                    anchorOffset = new egret.Point(p_s_distance, 0)

                } else {
                    anchorPoint = this.bc
                    shadow_p = this.getProjectivePoint(m_o_mid, k_mid, anchorPoint);
                    const p_s_distance = egret.Point.distance(anchorPoint, shadow_p);
                    angle = -this.angle(ori, mp, tc);
                    anchorOffset = new egret.Point(p_s_distance, this.maskWidth)
                }

            } else if (this.corner === "br") {
                ori = new egret.Point(this.bc.x + this.page_size.x, this.bc.y);
                //翻页点和角点中点
                const m_o_mid = new egret.Point((mp.x + ori.x) / 2, (mp.y + ori.y) / 2);
                //中垂线斜率
                const k_mid = -1 / this.getSlope(mp, ori);

                if (mp.y <= bc.y) {
                    anchorPoint = this.bc
                    shadow_p = this.getProjectivePoint(m_o_mid, k_mid, anchorPoint);
                    const p_s_distance = egret.Point.distance(anchorPoint, shadow_p);
                    angle = this.angle(ori, mp, bc);
                    anchorOffset = new egret.Point(this.maskWidth - p_s_distance, this.maskWidth)

                } else {
                    anchorPoint = this.tc
                    shadow_p = this.getProjectivePoint(m_o_mid, k_mid, anchorPoint);
                    const p_s_distance = egret.Point.distance(anchorPoint, shadow_p);
                    angle = -this.angle(ori, mp, bc);
                    anchorOffset = new egret.Point(this.maskWidth - p_s_distance, 0)
                }

            } else if (this.corner === "bl") {
                ori = new egret.Point(this.bc.x - this.page_size.x, this.bc.y);
                //翻页点和角点中点
                const m_o_mid = new egret.Point((mp.x + ori.x) / 2, (mp.y + ori.y) / 2);
                //中垂线斜率
                const k_mid = -1 / this.getSlope(mp, ori);

                if (mp.y < bc.y) {
                    anchorPoint = this.bc
                    shadow_p = this.getProjectivePoint(m_o_mid, k_mid, anchorPoint);
                    const p_s_distance = egret.Point.distance(anchorPoint, shadow_p);
                    angle = -this.angle(ori, mp, bc);
                    anchorOffset = new egret.Point(p_s_distance, this.maskWidth)

                } else {
                    anchorPoint = this.tc
                    shadow_p = this.getProjectivePoint(m_o_mid, k_mid, anchorPoint);
                    const p_s_distance = egret.Point.distance(anchorPoint, shadow_p);
                    angle = this.angle(ori, mp, bc);
                    anchorOffset = new egret.Point(p_s_distance, 0)
                }

            }


            if (isNaN(anchorOffset.x) || isNaN(anchorOffset.y)) { return }

            this.handlerPageMask.anchorOffsetX = anchorOffset.x;
            this.handlerPageMask.anchorOffsetY = anchorOffset.y;
            this.handlerPageMask.x = anchorPoint.x;
            this.handlerPageMask.y = anchorPoint.y;
            this.handlerPageMask.rotation = angle;

            console.log("x:" + anchorOffset.x + "y:" + anchorOffset.y)
            console.log("x:" + anchorPoint.x + "y:" + anchorPoint.y)
            console.log(anchorOffset.x == Number.NaN)
            console.log(this.corner)

            this.staticMask.anchorOffsetX = anchorOffset.x;
            this.staticMask.anchorOffsetY = anchorOffset.y;
            this.staticMask.x = anchorPoint.x;
            this.staticMask.y = anchorPoint.y;
            this.staticMask.rotation = angle;

            let handlerPageAnchor: egret.Point;
            if (this.corner === "tr") {
                handlerPageAnchor = new egret.Point(0, 0)

            } else if (this.corner === "tl") {
                handlerPageAnchor = new egret.Point(this.page_size.x, 0)

            } else if (this.corner === "br") {
                handlerPageAnchor = new egret.Point(0, this.page_size.y)

            } else if (this.corner === "bl") {
                handlerPageAnchor = new egret.Point(this.page_size.x, this.page_size.y)

            }
            this.handlerPage.anchorOffsetX = handlerPageAnchor.x;
            this.handlerPage.anchorOffsetY = handlerPageAnchor.y;
            this.handlerPage.x = mp.x;
            this.handlerPage.y = mp.y;
            this.handlerPage.rotation = 2 * angle;



        }
    }

    private onBegin(evt: egret.TouchEvent) {
        if (this.folding || this.animating) { return }
        const x = evt.localX;
        const y = evt.localY;

        const tl = new egret.Point(this.tc.x - this.page_size.x, this.tc.y);
        const tr = new egret.Point(this.tc.x + this.page_size.x, this.tc.y);
        const bl = new egret.Point(this.bc.x - this.page_size.x, this.bc.y);
        const br = new egret.Point(this.bc.x + this.page_size.x, this.bc.y);

        const size = new egret.Point(100, 100);


        if (x > tl.x && x < (tl.x + size.x) && y > tl.y && y < (tl.y + size.y)) {
            this.corner = "tl";
        } else if (x > (tr.x - size.x) && x < tr.x && y > tr.y && y < (tr.y + size.y)) {
            this.corner = "tr";
        } else if (x > bl.x && x < (bl.x + size.x) && y > (bl.y - size.y) && y < bl.y) {
            this.corner = "bl";
        }
        else if (x > (br.x - size.x) && x < br.x && y > (br.y - size.y) && y < br.y) {
            this.corner = "br";
        } else {
            this.corner = null;
        }

        if (this.corner === "tl" || this.corner === "bl") {
            if (this.leftPage.visible === false) {
                this.corner = null;
            }
        }
        if (this.corner === "tr" || this.corner === "br") {
            if (this.rightPage.visible === false) {
                this.corner = null;
            }
        }

        if (this.corner) {

        }
        console.log(this.corner)
    }


    public getSlope(point1, point2) {
        if (point1.x === point2.x) {
            throw "error";
        }
        return (point2.y - point1.y) / (point2.x - point1.x);
    }
    public getProjectivePoint(pLine: egret.Point, k: number, pOut: egret.Point) {
        const point = new egret.Point();
        point.x = ((k * pLine.x + pOut.x / k + pOut.y - pLine.y) / (1 / k + k));
        point.y = (-1 / k * (point.x - pOut.x) + pOut.y);
        return point;
    }
    public angle(v0: egret.Point, v1: egret.Point, v2: egret.Point) {

        const va = new egret.Point(v1.x - v0.x, v1.y - v0.y)
        const vb = new egret.Point(v2.x - v0.x, v2.y - v0.y)

        const pvalue = va.x * vb.x + va.y * vb.y;
        const va_m = Math.sqrt(va.x * va.x + va.y * va.y);
        const vb_m = Math.sqrt(vb.x * vb.x + vb.y * vb.y);

        let cosV = pvalue / (va_m * vb_m);
        if (cosV < -1 && cosV > -2) {
            cosV = -1
        } else if (cosV > 1 && cosV < 2) {
            cosV = 1;
        }

        return Math.acos(cosV) * 180 / Math.PI
    }

}
